"use client"

import { useRouter } from "next/navigation"
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import type { DeliveryMethod } from "@/app/page"

interface ExpressPaymentModalProps {
  isOpen: boolean
  onClose: () => void
  paymentType: "applepay" | "googlepay"
  total: number
  deliveryMethod: DeliveryMethod
}

const DELIVERY_LABELS: Record<DeliveryMethod, string> = {
  bolt: "Metagame Bolt - Személyes átvétel",
  klub: "Metagame Klub - Személyes átvétel",
  delivery: "Házhozszállítás",
}

function formatPrice(amount: number): string {
  return new Intl.NumberFormat("hu-HU", {
    style: "decimal",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount) + " Ft"
}

export function ExpressPaymentModal({ 
  isOpen, 
  onClose, 
  paymentType, 
  total, 
  deliveryMethod 
}: ExpressPaymentModalProps) {
  const router = useRouter()

  const handlePayment = () => {
    onClose()
    router.push("/success")
  }

  const isApplePay = paymentType === "applepay"

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="bg-card border-0 sm:max-w-[400px] rounded-xl shadow-2xl shadow-black/60 p-6">
        <DialogTitle className="sr-only">
          {isApplePay ? "Apple Pay" : "Google Pay"} fizetés
        </DialogTitle>
        <DialogDescription className="sr-only">
          Erősítse meg a fizetést {isApplePay ? "Apple Pay" : "Google Pay"} segítségével
        </DialogDescription>

        {/* Payment method header */}
        <div className="flex items-center justify-center gap-2 mb-6">
          {isApplePay ? (
            <div className="flex items-center gap-2 bg-black text-white px-4 py-2 rounded-lg">
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.05 20.28c-.98.95-2.05.8-3.08.35-1.09-.46-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.35C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.5-1.31 2.99-2.54 4.09l.01-.01zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z"/>
              </svg>
              <span className="font-medium">Pay</span>
            </div>
          ) : (
            <div className="flex items-center gap-2 bg-white text-neutral-800 px-4 py-2 rounded-lg">
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
              </svg>
              <span className="font-medium">Pay</span>
            </div>
          )}
        </div>

        {/* Order details */}
        <div className="space-y-4 mb-6">
          {/* Total */}
          <div className="flex items-center justify-between py-3 border-b border-border/30">
            <span className="text-muted-foreground">Összesen</span>
            <span className="text-2xl font-bold text-primary tabular-nums">
              {formatPrice(total)}
            </span>
          </div>

          {/* Delivery method */}
          <div className="flex items-center justify-between py-2">
            <span className="text-muted-foreground text-sm">Átvétel</span>
            <span className="text-sm text-foreground">{DELIVERY_LABELS[deliveryMethod]}</span>
          </div>

          {/* Payment method */}
          <div className="flex items-center justify-between py-2">
            <span className="text-muted-foreground text-sm">Fizetési mód</span>
            <span className="text-sm text-foreground">
              {isApplePay ? "Apple Pay" : "Google Pay"}
            </span>
          </div>
        </div>

        {/* Actions */}
        <div className="space-y-3">
          <Button 
            onClick={handlePayment}
            className={`w-full h-12 font-semibold text-base rounded-lg ${
              isApplePay 
                ? "bg-black hover:bg-neutral-900 text-white" 
                : "bg-white hover:bg-neutral-100 text-neutral-800"
            }`}
          >
            {isApplePay ? (
              <span className="flex items-center gap-2">
                Fizetés
                <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M17.05 20.28c-.98.95-2.05.8-3.08.35-1.09-.46-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.35C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.5-1.31 2.99-2.54 4.09l.01-.01zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z"/>
                </svg>
                Pay
              </span>
            ) : (
              <span className="flex items-center gap-2">
                Fizetés
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                </svg>
                Pay
              </span>
            )}
          </Button>
          
          <Button 
            variant="ghost" 
            onClick={onClose}
            className="w-full h-10 text-muted-foreground hover:text-foreground"
          >
            Mégse
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
